#Homework Assignment #1 -Variables

#What's my favorite song?


def main():
    print("My favorite song currently is Blessed")
    Artist = "Wizkid Ayo Balogun"
    FeaturedArtist = "Damian Marley"
    Album = "Made in Lagos"
    Genre = "Afrobeats"
    DurationInSeconds = (60 * 4 + 23)
    YearOfReleased = 2020
    MonthOfReleased = "November"
    Video = "Not yet released"
    PersonalRating = "9.999 / 10"

    print(Artist)
    print(FeaturedArtist)
    print(Album)
    print(Genre)
    print(DurationInSeconds)
    print(YearOfReleased)
    print(MonthOfReleased)
    print(Video)
    print(PersonalRating)

"""
To calculate the DurationInSeconds,
instead of assigning a direct integer,
I inputed a mathematical expression that
would inturn equate to be that value.

"""
